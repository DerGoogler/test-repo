MODPATH="${0%/*}"
exec $MODPATH/system/bin/wpd